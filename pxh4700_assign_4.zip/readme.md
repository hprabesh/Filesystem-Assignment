Step: To compile the program, please type 'make' and it will do all the compilation for you

Step 2: Next, type ./main to start opening the mfs prompt

Note: All functionalities are working (I verified this on omega server), except 'open' file system. Createfs and savefs is also working.  
